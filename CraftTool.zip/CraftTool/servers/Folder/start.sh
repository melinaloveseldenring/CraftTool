#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if [ ! -f "server.jar" ]; then
  echo "Missing server.jar. Place your authorized Paper/Spigot server JAR here and name it server.jar."
  exit 1
fi
if ! grep -q "^eula=true$" eula.txt 2>/dev/null; then
  echo "Review the Minecraft EULA, then set eula=true in eula.txt if you agree."
  exit 1
fi
exec java -Xms1G -Xmx2G -jar server.jar nogui
