@echo off
cd /d %~dp0
if not exist "server.jar" (echo Missing server.jar. Add your authorized server JAR and rename it server.jar & pause & exit /b 1)
findstr /x "eula=true" eula.txt >nul || (echo Review the Minecraft EULA and set eula=true in eula.txt if you agree. & pause & exit /b 1)
java -Xms1G -Xmx2G -jar server.jar nogui
pause
