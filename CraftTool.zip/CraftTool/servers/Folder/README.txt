CRAFTTOOL SERVER REPLICA
========================

Replica folder: Folder
Scanned address: mercurymc.net:25565
Detected Minecraft version: Velocity 1.7.2-1.21.11
Observed MOTD: MercuryrMC *「1.8x - 1.21.x 」 !!! Come Join Our Discord discord.mercurymc.net !!!

WHAT WAS CREATED
- server.properties with values based on public scan information
- plugins/ and config/ folders
- start.sh and start.bat launch helpers
- crafttool-replica.json with scan metadata

SERVER SOFTWARE
This folder does not contain a Minecraft server JAR unless you copied an
authorized local server folder into it. Add a compatible Paper/Spigot server
JAR, name it server.jar, and review its version compatibility.

EAGLERCRAFT SUPPORT
EaglerXServer v1.1.1 is a server plugin, not a standalone server.
Use a compatible Spigot, BungeeCord, or Velocity setup and install only the
official plugin files you are authorized to use. Verify compatibility of
your selected server software before installing EaglerXServer.

PLUGINS AND FILES
A public network scan cannot download another server's private plugins,
world, configs, databases, or player data. If you supplied a local server
folder that you own or are authorized to copy, its files were copied into
this replica (excluding logs, crash reports, and player access/ban lists).

BEFORE STARTING
1. Add/verify the compatible server JAR as server.jar.
2. Review server.properties and plugin configuration.
3. Read the Minecraft EULA. If you agree, change eula=false to eula=true.
4. Run ./start.sh on Linux or start.bat on Windows.
5. Configure networking/firewall and Eaglercraft WebSocket access separately.

The scan describes public status at scan time; it is not a clone of the
remote server's private implementation.
